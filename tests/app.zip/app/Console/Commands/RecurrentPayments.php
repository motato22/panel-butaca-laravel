<?php

namespace App\Console\Commands;

use App\Models\Card;
use App\Models\Project;
use App\Models\Property;
use App\Models\Installment;

use Illuminate\Support\Carbon;
use Illuminate\Console\Command;
use Illuminate\Support\Facades\Log;

class RecurrentPayments extends Command
{
    /**
     * The name and signature of the console command.
     *
     * @var string
     */
    protected $signature = 'check:recurrent-payment';

    /**
     * The console command description.
     *
     * @var string
     */
    protected $description = 'Command description';

    /**
	 * Create a new command instance.
	 *
	 * @return void
	 */
	public function __construct()
	{
		parent::__construct();
		date_default_timezone_set('America/Mexico_city');
	}

    /**
     * Execute the console command.
     *
     * @return int
     */
    public function handle()
    {
        $today = Carbon::now();
        // dd($today->isoFormat('Y-m-d H:i:s'));
        dd( $today->toDateTimeString() );
        $properties = Property::whereHas('installments', function($query) {
            $query->where('installment_status_id', '!=', 1);
        })->get();

        foreach ( $properties as $property ) {
            // dd($property->nextInstallment);
            // Ya ordenado por fecha de forma ascendente desde el modelo, sólo se necesita el primer registro
            $pendingInstallments = $property->installments->where('installment_status_id', '!=', 1)->first();
            if ( $pendingInstallments ) {
                /**
                 * La fecha debe ser mayor o igual a hoy
                 * Si es mayor, revisar que el día de pago sea el mismo que hoy, es decir
                 * Si se pagó por adelantado 2 meses, no puede haber un pago programado para ese mismo mes, debe ser uno diferente
                 * Si es mayor, hay que revisar el monto del adeudo que se tiene
                 */
            }
            // dd($pendingInstallments->id);
            
            // dd($property);
            # code...
        }
        // dd($properties);
        $count ++;
        // Log::info($message);
        return Command::SUCCESS;
    }
}
